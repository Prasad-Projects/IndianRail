'''
Created on Mar 16, 2015

@author: Asif
'''
import networkx as nx
import csv

myGraph = nx.Graph()
f1 = open("C:\\Users\\Asif\\Desktop\\AllWell.csv","r")
reader = csv.reader(f1)
distance = 0
for items in reader:
    
    src = items[0]
    target = items[1]
    myGraph.add_edge(src,target,weight = float(items[2]))
    
"""
myshortlist = nx.dijkstra_path(myGraph,'JAT','KTHU')

print(myshortlist)"""
