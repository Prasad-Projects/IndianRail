'''
Created on Mar 16, 2015

@author: Asif
'''
import csv
"""
f1 = open("C:\\Users\\Asif\\Desktop\\AllEdgess.csv","r")
mylist = []
reader = csv.reader(f1)
for lines in reader:
    mylist.append([lines[0],lines[1]])

f1.close()

f2 = open("EdgesList.csv","r")
f3 = open("TryAdd.csv","a+")
reader  = csv.reader(f2)
count = 0
for lines in reader:
    if([lines[0],lines[1]] not in mylist):
        mystring = ",".join(lines)
        f3.write(mystring)
        f3.write("\n")

f2.close()
f3.close()"""

f1 = open("C:\\Users\\Asif\\Desktop\\AllEdgess.csv","r")
myset = set()
reader = csv.reader(f1)
for lines in reader:
    myset.add(lines[0])
    myset.add(lines[1])

print(len(myset))
f1.close()

f2 = open("EdgesList.csv","r")
myset = set()
reader = csv.reader(f2)
for lines in reader:
    myset.add(lines[0])
    myset.add(lines[1])

print(len(myset))
f2.close()
