'''
Created on Mar 16, 2015

@author: Asif
'''
#Get All the Work done previously
#import networkx as nx
import csv
#import os
import re
#import pickle
from makenow import G
#from networkx.classes.function import number_of_nodes

from bs4 import BeautifulSoup

f = open("checkagain.csv","r")
reader = csv.reader(f)

myinit = 0
def getStationList(soup):
    global myinit
    mylist = []
    for row in soup.find_all('table')[-1].tbody.find_all('tr'):
        cells = row.find_all('td')
        adding = []
        
        try:
            cells[1] = re.sub('\s+', '', str(cells[1].get_text()))
            newdistance = float(re.sub('\s+', '', str(cells[3].get_text())))
            temp = newdistance
            newdistance -= myinit
            myinit = temp
            for elements in (cells[1],newdistance):
                adding.append(elements)
        except:
            return(None)
        
        mylist.append(adding)
    return(mylist)

def processPage(filename):
    global myinit
    #open the file
    f = open(filename,'r')
    #Read the contents of the page
    mystring = f.read()
    
    #Make the Soup object
    soup = BeautifulSoup(mystring)
    myinit = 0
    list_of_stations = getStationList(soup)
    
    #close the file
    f.close()
    return(list_of_stations)


for lines in reader:
    newfilename = "C:\\Users\\Asif\\Desktop\\RealDistance\\"+lines[0]+";"+lines[1]+".html"    
    mylist = processPage(newfilename)
    if(mylist):
        G.remove_edge(lines[0], lines[1])
        for go_i in range(1,len(mylist)):
            G.add_edge(mylist[go_i-1][0],mylist[go_i][0],weight = float(mylist[go_i][1]))

    #print(lines)

lastfile = open("C:\\Users\\Asif\\Desktop\\AllEdgess.csv","a+")
for items in G.edges():
    mystring = str(items[0])+","+str(items[1])+","+str(G[items[0]][items[1]]['weight'])+"\n"
    lastfile.write(mystring)
    
lastfile.close()
print("Done!!")




            
     
        
    
