'''
Created on Mar 16, 2015

@author: Asif
'''
import networkx as nx
from networkx.classes.function import number_of_nodes, number_of_edges, degree
from lastlast import myGraph as SpaceOfStations
from networkx.algorithms.distance_measures import diameter, eccentricity
from networkx.algorithms.components.connected import connected_components
SpaceOfStops = nx.Graph()
total_trains = set()
f = open("EdgeswithTrainNumbers.txt","r")
for lines in f.readlines():
    lines = (lines.strip("\n")).split(",")
    total_trains.add(lines[0])
    if(SpaceOfStops.has_edge(lines[1], lines[2])):
        SpaceOfStops.add_edge(lines[1],lines[2],weight=int(SpaceOfStops[lines[1]][lines[2]]['weight'])+1)
    else:
        SpaceOfStops.add_edge(lines[1],lines[2],weight = 1)


Nodes_Stops = SpaceOfStops.nodes()
Nodes_Stations = SpaceOfStations.nodes()

for nodes in Nodes_Stations:
    if(nodes not in Nodes_Stops):
        SpaceOfStops.add_node(nodes)
        go = nodes

#print "The Number of nodes are",number_of_nodes(SpaceOfStops)
#print "The total number of Edges in the Physical Graph are",number_of_edges(SpaceOfStations)
"""
maxs = 0
i = 1
for mynodes in SpaceOfStations.nodes():
    newnum = eccentricity(SpaceOfStations, mynodes)
    if(newnum == 585):
        print(mynodes)
        break
    i +=1
    if(i%100 == 0):
        print(i)"""
    
    
#print "The Diameter of the Physical Graph is",eccentricity(SpaceOfStations, "PUU")
"""
path=nx.single_source_shortest_path(SpaceOfStations,"PUU")
for items in path.keys():
    if(len(path[items]) == 585):
        print(path[items])"""
#print "The number of Edges in the Logical Graph is",number_of_edges(SpaceOfStops)

f.close()

f1 = open("C:\\Users\\Asif\\Desktop\\PhysicalNodeDegree.csv","a+")
for mynodes in SpaceOfStations.nodes():
    mystring = mynodes+","+str(SpaceOfStations.degree(mynodes))+"\n"
    f1.write(mystring)
f1.close()

print("Done PhysicalNodeDegree")
f1 = open("C:\\Users\\Asif\\Desktop\\LogicalNodeDegree.csv","a+")
for mynodes in SpaceOfStops.nodes():
    mystring = mynodes+","+str(SpaceOfStops.degree(mynodes))+"\n"
    f1.write(mystring)
f1.close()

print("Done LogicalNodeDegree")
f1 = open("C:\\Users\\Asif\\Desktop\\LogicalEdgeWeight.csv","a+")
for myedges in SpaceOfStops.edges():
    mystring = myedges[0]+","+myedges[1]+","+str(SpaceOfStops[myedges[0]][myedges[1]]['weight'])+"\n"
    f1.write(mystring)
f1.close()

    