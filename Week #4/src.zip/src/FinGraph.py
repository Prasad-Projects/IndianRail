'''
Created on Mar 16, 2015

@author: Asif
'''
import csv

import re

import networkx as nx
from bs4 import BeautifulSoup

G = nx.Graph()
myinit = 0
def getStationList(soup):
    global myinit
    mylist = []
    for row in soup.find_all('table')[-1].tbody.find_all('tr'):
        cells = row.find_all('td')
        adding = []
        
        try:
            cells[1] = re.sub('\s+', '', str(cells[1].get_text()))
            newdistance = float(re.sub('\s+', '', str(cells[3].get_text())))
            temp = newdistance
            newdistance -= myinit
            myinit = temp
            for elements in (cells[1],newdistance):
                adding.append(elements)
        except:
            return(None)
        
        mylist.append(adding)
    return(mylist)

def processPage(filename):
    global myinit
    #open the file
    f = open(filename,'r')
    #Read the contents of the page
    mystring = f.read()
    
    #Make the Soup object
    soup = BeautifulSoup(mystring)
    myinit = 0
    list_of_stations = getStationList(soup)
    
    #close the file
    f.close()
    return(list_of_stations)

myfile = open("goLast.csv","r")
processed = 1
reader = csv.reader(myfile)
for lines in reader:    
    newfilename = "C:\\Users\\Asif\\Desktop\\BigDistance\\"+lines[0]+";"+lines[1]+".html"    
    mylist = processPage(newfilename)
    if(mylist and len(mylist)>2):
        for go_i in range(1,len(mylist)):
            G.add_edge(mylist[go_i-1][0],mylist[go_i][0],weight = float(mylist[go_i][1]))
    else:
        G.add_edge(lines[0],lines[1],weight=float(lines[2]))
    print(processed)
    processed += 1

lastfile = open("C:\\Users\\Asif\\Desktop\\AllEdgess.csv","r")
processed = 1
myfile.close()
reader = csv.reader(lastfile)
for lines in reader:
    if(processed <= 2500):
        processed += 1
        continue
    G.add_edge(lines[0],lines[1],weight=float(lines[2]))
lastfile.close()

lastfile = open("C:\\Users\\Asif\\Desktop\\AllWell.csv","a+")
for items in G.edges():
    mystring = str(items[0])+","+str(items[1])+","+str(G[items[0]][items[1]]['weight'])+"\n"
    lastfile.write(mystring)
    
lastfile.close()
print("Done!!")

        
        
        
