'''
Created on Feb 27, 2015

@author: Asif
'''
#Get All the Work done previously
import networkx as nx
from makenow import G
#from networkx.classes.function import number_of_nodes

myshortlist = nx.dijkstra_path(G,'TPTY','HX')
total_distance = 0
for i in range(len(myshortlist)-1):
    total_distance += float(G[myshortlist[i]][myshortlist[i+1]]['weight'])
print(myshortlist,total_distance)

#print(G.number_of_nodes())